package softuni.exam.service.impl;

import org.springframework.stereotype.Service;
import softuni.exam.repository.AstronomerRepository;
import softuni.exam.service.AstronomerService;

import javax.xml.bind.JAXBException;
import java.io.IOException;

@Service
public class AstronomerServiceImpl implements AstronomerService {
    private static final String ASTRONOMERS_FILE_PATH = "src/main/resources/files/xml/astronomers.xml";
    private AstronomerRepository astronomerRepository;

    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readAstronomersFromFile() throws IOException {
        return null;
    }

    @Override
    public String importAstronomers() throws IOException, JAXBException {
        return null;
    }
}
